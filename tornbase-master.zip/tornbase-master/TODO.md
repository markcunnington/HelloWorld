# To do

### In progress

### P1 - Bugs
### P2 - Core
### P3 - Current interest
- include all API calls

### P5 - Future improvement
- calculate drug price
- calculate how many morphine for job point
- remember previous training gain and compare with current gain

### Done
- Tornbase v0.3.3
